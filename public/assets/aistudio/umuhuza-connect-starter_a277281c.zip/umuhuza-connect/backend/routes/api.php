<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\JobController;
use App\Http\Controllers\Api\ApplicationController;
use App\Http\Controllers\Api\ProductController;
use App\Http\Controllers\Api\DashboardController;

Route::prefix('v1')->group(function () {
    Route::get('/health', fn () => response()->json(['status' => 'ok', 'app' => 'Umuhuza Connect API']));
    Route::get('/dashboard', [DashboardController::class, 'show']);
    Route::get('/jobs', [JobController::class, 'index']);
    Route::get('/jobs/{job}', [JobController::class, 'show']);

    // Protect write operations with Sanctum in the Laravel app.
    Route::middleware('auth:sanctum')->group(function () {
        Route::post('/jobs/{job}/applications', [ApplicationController::class, 'store']);
        Route::get('/my-applications', [ApplicationController::class, 'mine']);
        Route::get('/products', [ProductController::class, 'index']);
        Route::post('/products', [ProductController::class, 'store']);
    });
});
