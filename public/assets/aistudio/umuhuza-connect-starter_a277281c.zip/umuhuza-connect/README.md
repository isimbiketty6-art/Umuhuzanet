# Umuhuza Connect — Human OS (Rwanda MVP)

A modular full-stack starter with:
- `frontend/`: React + Vite + TypeScript + Tailwind CSS, dark responsive dashboard.
- `backend/`: Laravel API scaffold instructions, routes, controllers, models, migrations, and seed data to copy into a Laravel 11/12 project.

## MVP scope
This starter focuses on the first usable vertical slice: role-aware dashboard, jobs, applications, companies, seller/product listings, profile basics, notifications, and admin moderation foundations. Learning, AI copilot, payments, real-time chat, and advanced analytics are planned extension modules—not represented as production-complete.

## Prerequisites
- Node.js 20+
- PHP 8.2+
- Composer 2
- MySQL 8+
- Git

## 1. Frontend quick start
```bash
cd frontend
npm install
cp .env.example .env
npm run dev
```
The UI runs at the Vite URL (usually `http://localhost:5173`). Without a running API, it uses clearly labeled demo data. To connect to Laravel, set `VITE_API_BASE_URL=http://127.0.0.1:8000/api` in `.env`.

## 2. Create Laravel backend
The `backend/` folder contains starter files intended to be merged into a fresh Laravel app. From the repository root:
```bash
composer create-project laravel/laravel backend-app
```
Copy the contents of `backend/app`, `backend/database`, and `backend/routes/api.php` into `backend-app/` (merge carefully if files exist). Then:
```bash
cd backend-app
cp .env.example .env
php artisan key:generate
```
Create a MySQL database named `umuhuza_connect`, set `DB_*` values in `.env`, then:
```bash
php artisan migrate --seed
php artisan serve
```
Use Laravel Sanctum for SPA authentication. Before exposing the API publicly, configure Sanctum stateful domains, CORS, HTTPS, email verification, password reset, throttling, and production secrets.

## 3. Security / production checklist
- Do not store plaintext passwords; use Laravel's password hashing.
- Apply server-side policies for every protected resource and every role.
- Validate uploads (MIME, size, storage visibility); keep CVs private.
- Add email/phone verification and account recovery.
- Add abuse reporting, moderation queues, audit logs, backups, monitoring, and rate limits.
- Never accept payment card details directly; use a compliant payment provider when the payment module is implemented.
- Seed data is illustrative. Replace it with verified employers/jobs before public launch.

## 4. Suggested build order
1. Authentication and profiles.
2. Employer/company verification and job CRUD.
3. Applications and status workflow.
4. Seller storefronts and product/service listings.
5. Messaging, notifications, and moderation.
6. Billing/subscriptions and analytics.
7. Learning modules and AI-assisted matching.

## 5. Project layout
```text
umuhuza-connect/
  frontend/
    src/
      components/
      data/
      lib/
      App.tsx
      main.tsx
      index.css
    package.json
    vite.config.ts
    tailwind.config.js
  backend/
    app/Models/
    app/Http/Controllers/Api/
    database/migrations/
    database/seeders/
    routes/api.php
```
